function addUser() {
  const user = {
    f_name: document.querySelector("#first_name").value,
    l_name: document.querySelector("#last_name").value,
    username: document.querySelector("#username").value,
    email: document.querySelector("#email").value,
  };
  let userAsString = JSON.stringify(user);
  localStorage.setItem("user", userAsString);
  location.href = "thankyou.html";
}
